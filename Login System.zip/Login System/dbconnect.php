<?php
$server = "localhost";
$username = "root";
$password = "";
$databse = "users19";

$con = mysqli_connect($server,$username,$password,$databse);
if(!$con)
{
    die("Error". mysqli_connect_error());
}


?>