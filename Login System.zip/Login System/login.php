<?php
$login = false;
$showError = false;
if($_SERVER["REQUEST_METHOD"] == "POST")
{
  include 'dbconnect.php';
  $username = $_POST["username"];
  $password = $_POST["password"];
      // $sql = "SELECT * FROM `tbl_u` WHERE `username` = '$username' AND `password` = '$password'";
      $sql = "SELECT * FROM `tbl_u` WHERE `username` = '$username'";

      $res = mysqli_query($con,$sql);
      $num = mysqli_num_rows($res);
      if($num== 1)
      {
        while($row = mysqli_fetch_assoc($res))
        {
          if(password_verify($password, $row['password']))
          {
            $login = true;
            session_start();
            $_SESSION['logedin'] = true;
            $_SESSION['username'] = $username;
            header("location: welcome.php"); //this function is used to redirect/ send given location 
          }
            else 
            {
              $showError = true;
            }
        }
      } 
  else 
  {
    $showError = true;
  }
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Login</title>
  </head>
  <body>
    <?php
    require 'nav.php';
    ?>
    <?php
    if ($login){
    echo '
    <div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>SUCCESS!</strong> You are Loged in.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
    }
?>
  <?php
    if ($showError){
    echo '
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>INCORRECT!</strong> Invalid Username or Password.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
    }
?>
    <div class="container my-4">
        <h1 class="text-center">Login To Our Website</h1>
                    <form action="/LOGIN SYSTEM/login.php" method="POST">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" id="username" name="username" aria-describedby="emailHelp" placeholder="Enter Your Name" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Enter Your Password" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Login</button>
                    </form>
    </div>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>